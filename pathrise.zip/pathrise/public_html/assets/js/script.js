$(document).ready(function () {
//navbar add remove calss
    var header = $(".no-background");
    $(window).on('scroll', function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 1) {
            header.removeClass('no-background').addClass("topbar-bg");
        } else {
            header.removeClass("topbar-bg").addClass('no-background');
        }
    });

// Navbar collapse hide
    $('.navbar-collapse .navbar-toggler').on('click', function () {
        $('.navbar-collapse').collapse('hide');
    });

    AOS.init();



});